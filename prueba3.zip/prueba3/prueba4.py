print("¡Hola, mundo!")
