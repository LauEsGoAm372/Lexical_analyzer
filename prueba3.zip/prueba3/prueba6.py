# Define una función lambda que suma dos números
suma = lambda a, b: a + b

# Usa la función lambda para sumar dos números
resultado = suma(3, 4)

# Imprime el resultado
print(resultado)

