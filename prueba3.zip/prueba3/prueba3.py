a = 5
b = 10
c = 15

if a < b and b < c:
    print("a es menor que b y b es menor que c")
